using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Button)), Serializable]
public class ClassButton : MonoBehaviour
{
    [SerializeField] private GameObject selectedButton;
    [SerializeField] private GameObject unselectedButton;
    [SerializeField] private Image selectedIcon;
    [SerializeField] private Image unselectedIcon;
    [SerializeField] private TextMeshProUGUI selectedText;
    [SerializeField] private TextMeshProUGUI unselectedText;
    [SerializeField] public Button button;

    public void UpdateDisplay(Sprite icon, string select, string unselect)
    {
        selectedIcon.sprite = icon;
        unselectedIcon.sprite = icon;
        selectedText.text = select;
        unselectedText.text = unselect;
    }
    
    public void SetSelected(bool isSelected)
    {
        selectedButton.SetActive(isSelected);
        unselectedButton.SetActive(!isSelected);
    }
}
