public interface IGameEvent
{
    
}
