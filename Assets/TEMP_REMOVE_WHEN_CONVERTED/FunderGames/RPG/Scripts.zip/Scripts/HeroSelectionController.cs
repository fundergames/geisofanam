using System;
using UnityEngine;
using System.Collections.Generic;

namespace FunderGames.RPG.UI
{
    [Serializable]
    public class HeroSelectionController : UIWindow
    {
        private static readonly int PlayRandom = Animator.StringToHash("PlayRandom");

        [Header("Views")]
        [SerializeField] private ClassSelectionView classSelectionView;
        [SerializeField] private CharacterStatsView statsView;
        [SerializeField] private CharacterLevelView levelView;
        [SerializeField] private CharacterClassDescriptionView classDescriptionView;
        [SerializeField] private Material characterMaterial;
        
        [Header("Character Information")]
        [SerializeField] private List<HeroData> heroes = new();
        [SerializeField] private Transform heroesParent;
        private Dictionary<HeroData, GameObject> spawnedHeroes = new();

        private PlayerData playerData;
        private HeroData selectedHero;

        public override void Show()
        {
            InitializePlayerData();
            SetupView();
        }
        
        public override void Hide()
        {
            InitializePlayerData();
            SetupView();
        }

        private void InitializePlayerData()
        {
            // In a real scenario, you'd load this data from a save file or server
            playerData = new PlayerData(50000);
        }

        private void SetupView()
        {
            classSelectionView.UpdateDisplay(heroes, OnHeroSelected);
            if (heroes.Count > 0)
            {
                OnHeroSelected(heroes[0]);
            }
        }

        private void OnHeroSelected(HeroData hero)
        {
            if (selectedHero == hero) return;
            selectedHero = hero;
            statsView.UpdateDisplay(hero.StatList);
            levelView.UpdateDisplay(hero.Level, "Level", "0.0%");
            classDescriptionView.UpdateDisplay(hero);

            if (!spawnedHeroes.TryGetValue(hero, out var spawned))
            {
                spawned = Instantiate(hero.HeroVisualData.characterPrefab, heroesParent, false);
                ChangeMaterialRecursively(spawned.transform, characterMaterial);
                spawnedHeroes.Add(hero, spawned);
                
                var anim = spawned.GetComponent<Animator>();
                if (anim != null)
                {
                    var newController = new AnimatorOverrideController(hero.AnimatorData.characterSelectAnimator)
                    {
                        ["Idle"] = hero.AnimatorData.idleClip,
                        ["Random_1"] = hero.AnimatorData.tauntAnimationClip
                    };

                    anim.runtimeAnimatorController = newController;
                }
            }
            
            foreach (var h in heroes)
            {
                if (spawnedHeroes.TryGetValue(h, out var obj))
                {
                    obj.SetActive(h == hero);
                }
            }
            
            var animator = spawned.GetComponent<Animator>();
            if (animator != null)
            {
                animator.SetTrigger(PlayRandom);
            }
            heroesParent.transform.SetPositionAndRotation(heroesParent.transform.position, new Quaternion(0,0,0,0));
        }
        
        void ChangeMaterialRecursively(Transform currentObject, Material mat)
        {
            var renderer = currentObject.GetComponent<Renderer>();

            if (renderer != null)
            {
                renderer.materials = new[] { mat };  
            }

            // Recursively process all child objects
            foreach (Transform child in currentObject)
            {
                ChangeMaterialRecursively(child, mat); 
            }
        }
        

        private void OnSelectButtonClicked()
        {
            if (selectedHero != null)
            {
                Debug.Log($"Selected hero: {selectedHero.PlayerName}");
                // Add logic here to handle hero selection (e.g., add to player's team, start a game, etc.)
            }
        }

        private void OnBackButtonClicked()
        {
            WindowManager.Instance.CloseTopWindow();
        }

        private void OnHomeButtonClicked()
        {
            WindowManager.Instance.CloseAllWindows();
            // Add logic here to return to the main menu or home screen
        }
    }
}

