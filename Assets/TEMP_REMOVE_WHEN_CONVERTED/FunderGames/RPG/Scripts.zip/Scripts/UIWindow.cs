using UnityEngine;

namespace FunderGames.RPG.UI
{
    public abstract class UIWindow : MonoBehaviour
    {
        public abstract void Show();
        public abstract void Hide();
    }
}