using UnityEngine;

namespace FunderGames.RPG
{
    public class CharacterStatsView : MonoBehaviour
    {
        [SerializeField] private GameObject sliderPrefab;

        public void UpdateDisplay(StatsData data)
        {
            foreach (Transform child in transform)
            {
                Destroy(child.gameObject);
            }

            foreach (var stat in data.Stats)
            {
                var slider = Instantiate(sliderPrefab, transform);
                var sliderComponent = slider.GetComponent<StatsSlider>();
                if (sliderComponent != null)
                {
                    sliderComponent.UpdateView(stat.DisplayText, stat.Icon, stat.Amount, stat.Color);
                }
            }
        }
    }
}