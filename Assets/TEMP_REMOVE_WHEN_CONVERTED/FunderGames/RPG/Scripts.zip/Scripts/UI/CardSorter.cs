using UnityEngine;
using System.Collections.Generic;

public class CardSorter : MonoBehaviour
{
    public Camera mainCamera;
    public List<Renderer> cardRenderers = new List<Renderer>();

    void Update()
    {
        SortCards();
    }

    void SortCards()
    {
        cardRenderers.Sort((a, b) => 
            Vector3.Dot(mainCamera.transform.forward, b.transform.position - mainCamera.transform.position)
                .CompareTo(Vector3.Dot(mainCamera.transform.forward, a.transform.position - mainCamera.transform.position)));

        for (int i = 0; i < cardRenderers.Count; i++)
        {
            cardRenderers[i].material.renderQueue = 3000 + i; // 3000 is the start of the transparent queue
        }
    }
}