using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CharacterLevelView : MonoBehaviour
{ 
    public Slider statsSlider;
    public TextMeshProUGUI characterLevel;
    public TextMeshProUGUI characterLevelText;
    public TextMeshProUGUI characterProgressText;

    public void UpdateDisplay(int level, string levelText, string progressText)
    {
        characterLevel.text = level.ToString();
        characterLevelText.text = levelText;
        characterProgressText.text = progressText;
    }
}
