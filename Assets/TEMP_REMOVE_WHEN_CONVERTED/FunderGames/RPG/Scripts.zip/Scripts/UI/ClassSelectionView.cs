using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FunderGames.RPG.UI
{
    public class ClassSelectionView : MonoBehaviour
    {
        [SerializeField] private GameObject buttonPrefab;
        [SerializeField] private Transform content;

        private List<ClassButton> buttons = new();

        public void UpdateDisplay(List<HeroData> heroes, System.Action<HeroData> onHeroSelected)
        {
            buttons.Clear();
            foreach (Transform child in content)
            {
                Destroy(child.gameObject);
            }

            foreach (var hero in heroes)
            {
                var buttonObj = Instantiate(buttonPrefab, content);
                var button = buttonObj.GetComponent<ClassButton>();
                buttons.Add(button);
                button.UpdateDisplay(hero.CharacterClass.Icon, hero.CharacterClass.ClassDisplayName, hero.CharacterClass.ClassDisplayName);
                button.button.onClick.AddListener(() => onHeroSelected(hero));
                button.button.onClick.AddListener(() => SetSelectedButton(button.button));
            }
            
            SetSelectedButton(buttons[0].button);
        }

        private void SetSelectedButton(Button selectedButton)
        {
            foreach (var classButton in buttons)
            {
                var isSelected = classButton.button == selectedButton;
                classButton.SetSelected(isSelected);
            }
        }
    }
}