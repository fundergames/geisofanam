using UnityEngine;
using UnityEngine.UI;

namespace FunderGames.RPG
{
    public class HeroSelectionView : MonoBehaviour
    {
        [SerializeField] private Image heroFullImage;
        [SerializeField] private Text heroNameText;

        [SerializeField] private Text heroLevelText;
        [SerializeField] private Slider heroLevelSlider;
        [SerializeField] private Text heroPowerText;

        [SerializeField] private Button selectButton;
        [SerializeField] private Text coinsText;
        [SerializeField] private Button backButton;
        [SerializeField] private Button homeButton;

        public void UpdateDisplay(HeroData hero)
        {
            // heroFullImage.sprite = hero.fullImage;
            heroNameText.text = hero.PlayerName;
            heroLevelText.text = $"Level {hero.Level}";
            heroLevelSlider.value = hero.LevelProgress;
            heroPowerText.text = hero.Power.ToString();
        }

        public void UpdateCoinsDisplay(int coins)
        {
            coinsText.text = coins.ToString("N0");
        }

        public void SetSelectButtonListener(System.Action onSelectClicked)
        {
            selectButton.onClick.RemoveAllListeners();
            selectButton.onClick.AddListener(() => onSelectClicked());
        }

        public void SetBackButtonListener(System.Action onBackClicked)
        {
            backButton.onClick.RemoveAllListeners();
            backButton.onClick.AddListener(() => onBackClicked());
        }

        public void SetHomeButtonListener(System.Action onHomeClicked)
        {
            homeButton.onClick.RemoveAllListeners();
            homeButton.onClick.AddListener(() => onHomeClicked());
        }
    }
}