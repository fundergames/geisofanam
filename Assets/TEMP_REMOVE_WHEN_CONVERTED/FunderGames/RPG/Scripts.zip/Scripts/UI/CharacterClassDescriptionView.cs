using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace FunderGames.RPG
{
    public class CharacterClassDescriptionView : MonoBehaviour
    {
        public Image characterClassSprite;
        public TextMeshProUGUI playerName;
        public TextMeshProUGUI characterClassName;
        public TextMeshProUGUI description;

        public void UpdateDisplay(HeroData hero)
        {
            playerName.text = hero.PlayerName;
            characterClassSprite.sprite = hero.CharacterClass.Icon;
            characterClassName.text = hero.CharacterClass.ClassDisplayName;
            description.text = hero.CharacterClass.Description;
        }
    }
}