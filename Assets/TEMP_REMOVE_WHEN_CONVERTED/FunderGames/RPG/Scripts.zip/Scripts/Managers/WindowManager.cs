using UnityEngine;
using System.Collections.Generic;

namespace FunderGames.RPG.UI
{
    public class WindowManager : MonoBehaviour
    {
        private Stack<UIWindow> windowStack = new();
        
        [SerializeField] private HeroSelectionController heroSelectionWindowPrefab;
        [SerializeField] private Canvas canvas;
    
        private static WindowManager _instance;
        public static WindowManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = FindObjectOfType<WindowManager>();
                    if (_instance == null)
                    {
                        GameObject obj = new GameObject();
                        obj.name = typeof(WindowManager).Name;
                        _instance = obj.AddComponent<WindowManager>();
                    }
                }
                return _instance;
            }
        }
    
        private void Awake()
        {
            if (_instance == null)
            {
                _instance = this;
                DontDestroyOnLoad(gameObject);
            }
            else
            {
                Destroy(gameObject);
            }
        }

        public void Start()
        {
            Instance.ShowHeroSelectionWindow();
        }

        public void ShowHeroSelectionWindow()
        {
            ShowWindow(Instantiate(heroSelectionWindowPrefab, canvas.transform));
        }
    
        public void ShowWindow(UIWindow window)
        {
            if (windowStack.Count > 0)
            {
                windowStack.Peek().Hide();
            }
            windowStack.Push(window);
            window.Show();
        }
    
        public void CloseTopWindow()
        {
            if (windowStack.Count > 0)
            {
                UIWindow window = windowStack.Pop();
                window.Hide();
                Destroy(window.gameObject);
    
                if (windowStack.Count > 0)
                {
                    windowStack.Peek().Show();
                }
            }
        }
    
        public void CloseAllWindows()
        {
            while (windowStack.Count > 0)
            {
                UIWindow window = windowStack.Pop();
                window.Hide();
                Destroy(window.gameObject);
            }
        }
    }
}