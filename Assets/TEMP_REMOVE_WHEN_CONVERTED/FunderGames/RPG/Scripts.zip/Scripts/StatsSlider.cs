using TMPro;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Slider))]
public class StatsSlider : MonoBehaviour
{
    [SerializeField] private Image icon;
    [SerializeField] private TextMeshProUGUI displayText;
    [SerializeField] private Slider slider;
    [SerializeField] private Image sliderFillImage;
    
    public void UpdateView(string displayName, Sprite statIcon, float statValue, Color statColor)
    {
        displayText.text = displayName;
        displayText.color = statColor;
        icon.sprite = statIcon;
        icon.color = statColor;
        slider.value = statValue / 100f;
        sliderFillImage.color = statColor;
    }
}
